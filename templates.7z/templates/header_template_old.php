<?php
$logged='';
if((isset($_SESSION['logged'])) && (($_SESSION['logged'])==true)){
    $logged=true;
}else{
    $logged=false;
}
?>
<div id="header">
        <div id="nav">
            <ul>
                <li><a href="index.php"> Home</a></li>
                <li><a href="browse.php">Browse</a></li>
                <li><a href="advSearch.php">Advanced Retrieval</a></li>
                <li><a href="aboutUs.php">About Us</a></li>
                <li><a href="statistics.php">Statistics</a></li>
                <li><a href="help.php">Help</a></li>
                <!--<li><a href="dataDownload.php">Data Download</a></li>-->
                <?php
                if ($logged) {
                    echo "<li><a href=\"mypage.php\" >My Page</a></li>";
                    echo "<li><a href=\"logout.php\" >Logout</a></li";
                }else {
                    echo "<li><a href=\"signIn.php\">Login</a></li";
                }
                ?>
            </ul>
            
            <hr size="1" width="545" style="padding-left: 10px; alignment-adjust: auto;"/>
        </div>
    
    
    <div id="mainLogos">
        <img src="images/HAPPI logo-2.png" style="float: left; width: 105px; align: right;" alt=""/>
        <div style="padding-left: 105px;">
        <p style="color: white; font-size: 16px; "> A Database of<br/>
            <span style="padding-top: 10px;color:white;font-size: 26px; float:left;"> <b style='color: yellow;'>H</b>uman <b style='color: yellow;'>A</b>nnotated and <b style='color: yellow;'>P</b>redicted <b style='color: yellow;'>P</b>rotein <b style='color: yellow;'>I</b>nteractions</span></p>
        </div>
    </div>
    
</div>
<!--<hr size=8 noshade>-->
