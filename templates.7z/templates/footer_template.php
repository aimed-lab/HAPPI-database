<div id="footer">
    <p>All Rights Reserved. Copyright &copy; 2016-2017 by <a href="http://bio.informatics.uab.edu/" style="color: #A8A8A8;text-decoration: underline; font-style: italic">I3 Jake Y. Chen Group in Informatics Institute, School of Medicine </a>, University of Alabama at Birmingham.<br />
     <?php
		$filename = 'index.php';
			if (file_exists($filename)) {
 		   echo "This site was last modified: " . date ("F d Y.",	filemtime($filename));
}
?>

     </p>
</div>

<!--<?php include_once("../../templates/analyticstracking.php") ?>-->