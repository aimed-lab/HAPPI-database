<script>
    $(document).ready(function() {
        
        $('#tree').treeview({
            collasped:true,
            animated:"fast",
            control:"#sidetreecontrol",
            persist:"location"
        });
    });
</script>
<style>
    
</style>
<?php
$happiDoc = include_once '../documents-location.php';
include_once $happiDoc . 'classes/dbutility.php';
include_once $happiDoc . 'classes/utility.php';
?>
<div id="titleDiv">
    <h3>MESH Terms</h3>
</div>
<div id="sidetree" style="padding-left:22px;">
    <div class="treeheader">&nbsp;</div>
    <div id="sidetreecontrol"><a href="?#" style="text-decoration:underline">Collapse All</a> | <a href="?#" style="text-decoration:underline">Expand All</a></div>
</div>
<br/>
<br/>
    <ul id="tree">
            <?php
            $omimDisease = dbutility::getOmimSuperDisease();
            
            foreach ($omimDisease as $key) {
                $superterm = $key[0];
                $tree = $key[1];
                $proCnt = dbutility::getOmimDiseaseProteinsCnt($tree);
                echo "<li>$superterm  ($proCnt)";
                $omimSubDisease = dbutility::getOmimSubDisease($tree);
                foreach ($omimSubDisease as $sub) {
                   $subterm = $sub[0];
                    $subtree = $sub[1]; 
                    $proCnt2 = dbutility::getOmimDiseaseProteinsCnt($subtree);
                    $omimChildDisease = dbutility::getOmimCildDisease($subtree);
                echo "<ul>";
                echo "<li>$subterm  ($proCnt2)";
                    echo "<ul>";
                    foreach ($omimChildDisease as $chld) {
                        $chldterm = $chld[0];
                        $chldtree = $chld[1]; 
                        $proCnt3 = dbutility::getOmimDiseaseProteinsCnt($chldtree);
                        echo "<li><a href='diseaseProteins.php?dis=$chldterm' style='color:blue;'>$chldterm</a>  ($proCnt3)</li>";
                    }
                    echo "</ul>";
                echo "</li>";   
                echo "</ul>";
                }
                echo "</li>";
            }
            ?>
    </ul>
    


