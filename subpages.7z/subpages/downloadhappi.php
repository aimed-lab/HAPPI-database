<?php
if(!isset($_SESSION)){
        session_start();
}
$happiDoc=include_once '../documents-location.php';
include_once $happiDoc.'classes/dbutility.php';
include_once $happiDoc.'classes/utility.php';
$userEmail=$_SESSION['userEmail'];
$first_name = $_SESSION['fname'];
$userId=$_SESSION['userId'];
?>
<script>
    $(document).ready(function(){
     
        $( "#agreement-form" ).dialog({
                autoOpen: false,
                modal: true,
                width:600,
                height:400,
                buttons: {
                    "Download": function() {
//                        window.location.href = 'phps/download.php?download_file=jquery-ui-1.8.9.custom.zip';
//                        setTimeout(closeDialog, 1500);

//alert("user:"+email);
                        //var deleteList='';
                        var downloadVal = $(this).data('dataSelect');
                        //alert(downloadVal);
                        var selected=$("#agreement-form input[type='radio']:checked").val();
                         if(selected==='Agree'){
                             //alert("You selected"+selected);
                             
                             if(downloadVal ==='5_star'){
                             //$['#dlink'].html('<a href="subpages/download.php?download_file=export_5.txt"/>');
                                window.location.href = 'subpages/download.php?download_file=export_5.txt';
                              }
                              
                              else if(downloadVal ==='4_star'){
                                   window.location.href = 'subpages/download.php?download_file=export_4.txt';
                               }else if(downloadVal ==='3_star'){
                                   window.location.href = 'subpages/download.php?download_file=export_3.txt';
                               }else if(downloadVal ==='2_star'){
                                   window.location.href = 'subpages/download.php?download_file=export_2.txt';
                               }else if(downloadVal ==='1_star'){
                                   window.location.href = 'subpages/download.php?download_file=export_1.txt';
                               
                                }
                                $( this ).dialog( "close" );
                         } else{
                                alert("Please accept the agreement to download data");
                            }
                    },
                    Cancel: function() {
                        $( this ).dialog( "close" );
                    }
                }
            });
            
        $('#downloadBtn').click(function() {
            var dataSelect=$('input[name=group1]:checked').val();
            //alert(dataSelect);
             $( "#agreement-form" ).data('dataSelect', dataSelect).dialog( "open" );
                //$( "#agreement-form" ).dialog( "open" );
        });
    });
</script>
<style>
 </style>
<div id="actionDiv" style="margin-top:5px;margin-bottom: 25px;">
    </div>
<div id="status"></div>
<p>Please select the data to download.</p>
<form id="downloadSelect">
    
    <input type="radio" name="group1" value="5_star" checked="true"> 5 Star<br>
    <input type="radio" name="group1" value="4_star"> 4 Star<br>
    <input type="radio" name="group1" value="3_star"> 3 Star<br>
    <input type="radio" name="group1" value="2_star"> 2 Star<br>
    <input type="radio" name="group1" value="1_star"> 1 Star<br><br/>
    <input id="downloadBtn" type="button" value="Download"/>
</form>
<!--<a href="subpages/download.php?download_file=export_5.txt">Download</a>-->

<div id="agreement-form" title="Agreement">
    <div id="deleteStatus"></div>
    <span id='dlink'></span>
    <form>
        <i style="font-size:14px;">Please sign the agreement to download data.<br/></i>
        <h2>Availability</h2>
                    <p>The Human Annotated Protein Protein Interaction (HAPPI) Database is freely available to all
                        WWW users for querying and browsing purposes. Use of web crawler or bulk content downloading
                        tool for research purposes requires written permissions to the Discovery Informatics and
                        Computing Group at Indiana University - Purdue University Indianapolis. The entire content
                        of the database is also available for licensing from Indiana University.</p>
                    <h2>No warranty:</h2>
                    <p>The Discovery Informatics and Computing Group at Indiana University - Purdue University Indianapolis
                        (DICG) uses its best efforts to deliver a high quality copy of the Database and to verify that the
                        data contained therein have been selected on the basis of sound scientific judgement. However,
                        DICG makes no warranties to that effect, and DICG shall not be liable for any damage that may
                        result from errors or omissions in the Database.</p>
                    <h2>Copyright:</h2>
                    <p>The Human Annotated Protein Protein Interaction (HAPPI) Database was developed by the
                        generous grants available to Dr. Jake Chen and the Discovery Informatics and Computing
                        Group funded through Indiana University. A written agreement is required to redistribute,
                        derivatize, or encapsulate the HAPPI database in another database from Indiana University
                        and Jake Chen.</p>
        <br/>
        
        <input type="radio" name="group2" value="Agree">Agree<br>

    </form>
</div>
