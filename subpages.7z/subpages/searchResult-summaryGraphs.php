<?php
//echo "Summary";
global $happiDoc;
if(isset($_GET['srcprotein'])){
    $srcProtein=$_GET['srcprotein'];
    //echo $srcProtein;
    //print_searchSummary($srcProtein);
}
if(!(isset($_SESSION))) {
        session_start();
    }

if(isset($_SESSION['searchInteractionList'])){
    $srcInteractionArry = $_SESSION['searchInteractionList'];
    $happiDoc=include_once '../documents-location.php';
    include_once $happiDoc.'classes/dbutility.php';
    //include ('../classes/dbUtility.php');
    $targetList = dbutility::getDrugTargets($srcInteractionArry);
    $cntTarget=count($targetList);
    //echo "Target count ".$cntTarget;
    $diseaseList = dbutility::getDiseaseRelated($srcInteractionArry);
    $cntDisease=count($diseaseList);
    //echo "Disease count ".$cntDisease;
    $GoType = dbutility::getGoTypeCNT($srcInteractionArry);
    $goCellularCNT=$GoType['Cellular Component'];
    $goMolCNT=$GoType['Molecular Function'];
    $goBioCNT=$GoType['Biological Process'];
    $cellularTypes =dbutility::getGoType($srcInteractionArry, 'Cellular Component');
    $biologicalTypes =dbutility::getGoType($srcInteractionArry, 'Biological Process');
    $molecularTypes =dbutility::getGoType($srcInteractionArry, 'Molecular Function');

}

?>

        <script type="text/javascript" src="http://www.google.com/jsapi"></script>
 <script type="text/javascript">
        $(document).ready(function(){
              // Load the Visualization API and the piechart package.
              google.load('visualization', '1', {'packages':['piechart']});
              google.load('visualization', '1', {'packages':['corechart']});

              // Set a callback to run when the Google Visualization API is loaded.
              google.setOnLoadCallback(drawChart2);

              // Callback that creates and populates a data table,
              // instantiates the pie chart, passes in the data and
              // draws it.
              var tar = <?php echo $cntTarget;//$ltargets; ?>;

              var dis = <?php echo $cntDisease;//$ldisease; ?>;
//              function drawChart() {
//
//              // Create our data table.
//                var data = new google.visualization.DataTable();
//                data.addColumn('string', 'dataType');
//                data.addColumn('number', 'TotalCnt');
//                data.addRows([
//                  ['Cellular Component',goCell],
//                  ['Molecular Function',goMol],
//                  ['Biological Process',goBio]
//
//                ]);
//
//                // Instantiate and draw our chart, passing in some options.
//                var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
//                chart.draw(data, {width: 400, height: 240, is3D: true, title: 'GO Distribution',
//                    titleColor:'red',titleFontSize:'16px',colors:['orange','#87CEFA','#387C44']
//                });
//              }

              function drawChart2() {
                var data = new google.visualization.DataTable();
                data.addColumn('string', 'type');
                data.addColumn('number', 'count');
                
                data.addRows(2);

                data.setValue(0, 0, 'Drugs Targets');
                data.setValue(0, 1, tar);
                data.setValue(1, 0, 'Diseases');
                data.setValue(1, 1, dis);

                var chart = new google.visualization.ColumnChart($('#chart_div2'));
                chart.draw(data, {width: 400, height: 240, title: 'Interaction Summary',
                                  hAxis: {title: '', titleColor:'red'},
                                  legend:'none',titleColor:'red',
                                  titleFontSize:'16px',
                                  vAxis: {title: 'Count', titleColor:'red'}
                                 });
              }              
       }) ;
    </script>
    
    
    <!--Div that will hold the pie chart-->
    <!--
    <div id="chart_div" style="width:200px;height: 300px; float: left">
        This is chart div
    </div>
    -->
    <hr size=3 noshade>
    <center><h1> Interaction Summary Graphs for Interacting Proteins</h1></center>
    <hr size=3 noshade>
    <div  style="margin-top: 50px">
        <div id="chart_div2" style="">
            This is chart div 2
        </div>        
    </div>
    <div id="summary" style="">
        <?php
            echo "Target Count:".$cntTarget;
        ?>
        
    </div>
  

