<?php
$happiDoc=include_once '../documents-location.php';
include_once $happiDoc.'classes/dbutility.php';
include_once $happiDoc.'classes/utility.php';
if(!isset($_SESSION)){
    session_start();
}
$logged='';
if(isset($_SESSION['logged']) && ($_SESSION['logged']==false)){
    $logged =false;
}else{
    if(isset($_SESSION['userId'])){
                $uid=$_SESSION['userId'];
    }else{
        $uid='';
    }
}

$direction='';
$type='';
$proteinStr='';
$experiment='';
$reference='';
    
if(isset ($_POST['annotateProtein'])){
        $proteinStr=($_POST['annotateProtein']);
    }
    
    if(isset ($_POST['direction'])){
        $direction=($_POST['direction']);
    }

    if(isset ($_POST['type'])){
        $type=($_POST['type']);
    }
    if(isset ($_POST['experiment'])){
        $experiment=($_POST['experiment']);
    }
    if(isset ($_POST['reference'])){
        $reference=($_POST['reference']);
    }

if($proteinStr !=''){
    if(($direction != 'Not') || ($type != 'Not') || ($experiment!='') || ($reference!='')){
        //saveInteractionsList($listName,$listDescription,$interactionList);
        echo "<p class='success'>Annotation successfully saved.</p>";
    }
}

