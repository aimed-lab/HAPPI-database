<?php
global $happiDoc;
//include_once 'gChart.php';

include_once 'googlecharts_1.02.php';
$happiDoc=include_once '../documents-location.php';
    include_once $happiDoc.'classes/dbutility.php';
if(isset($_GET['srcprotein'])){
    $srcProtein=$_GET['srcprotein'];
    //echo $srcProtein;
}
if(!(isset($_SESSION))) {
        session_start();
    }

//if(isset($_SESSION['searchInteractionList'])){
    //$srcInteractionArry = $_SESSION['searchInteractionList'];
    
    //include ('../classes/dbUtility.php');
    $searchedList=explode(',',$srcProtein);
    $targetList = dbutility::get_all_DrugTargets($searchedList);
    $cntTarget=count($targetList);
    //echo "Target count ".$cntTarget;
    $diseaseList = dbutility::get_all_DiseaseRelated($searchedList);
    $cntDisease=count($diseaseList);

    $GoType = dbutility::get_all_GoTypeCNT($searchedList);
    $goCellularCNT=$GoType['Cellular Component'];
    $goMolCNT=$GoType['Molecular Function'];
    $goBioCNT=$GoType['Biological Process'];
    $cellularTypes =dbutility::get_all_GoType($searchedList, 'Cellular Component');
    $biologicalTypes =dbutility::get_all_GoType($searchedList, 'Biological Process');
    $molecularTypes =dbutility::get_all_GoType($searchedList, 'Molecular Function');
    $tableId='tb'.$srcProtein;
//}

?>
<script>
    //$('table').visualize();
</script>
<!-- http://www.filamentgroup.com/lab/update_to_jquery_visualize_accessible_charts_with_html5_from_designing_with/
<table id="">
	
	<thead>
		<tr>
			<th scope="col">Drug</th>
			<th scope="col">Disease</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td><?php echo $cntTarget;?></td>
			<td><?php echo $cntDisease;?></td>
		</tr>
	</tbody>
</table>
-->
<center><h2>Summary Graphs</h2></center><br/>

<?php

/// gChart   http://code.google.com/p/gchartphp/
//$barChart = new gBarChart(500,150,'g');
//$barChart->addDataSet(array(112,315,66,40));
//$barChart->setLegend(array("Target", "Disease"));
//$barChart->setColors(array("ff3344", "11ff11"));
//$barChart->setTitle("Bar Chart");
//$barChart->renderImage($_GET['post']);
//$barChart->setAutoBarWidth();


///http://code.google.com/p/googlechartseasyphpclass/wiki/Documentation

$data=$cntTarget.','.$cntDisease;
//$data=array('Target'=>array($cntTarget),
//        'disease'=>array($cntDisease)
//    );

        $moo= new googleChart($data,'bary');
        $moo->dimensions='400x125';
        //$moo->smartDataLabel($data);
        $moo->setLabelsMinMax();
        $moo->setLabels('Target|Disease','bottom');
        $moo->legend='Target|Disease';
        //$moo->colors=array('8800ff','4444ff');
        $moo->barWidth=40;
        //$moo->fillColor='00FF00';
        $moo->draw(true);

$data=$goCellularCNT.','.$goMolCNT.','.$goBioCNT;
        $moo= new googleChart($data,'pie');
        $moo->setLabels('Cellular|Molecular|Biological');
        $moo->dimensions='300x125';
        $moo->title='Gene Ontology';
        //$moo->colors=array('00ff00','8800ff','4444ff');
        //$moo->fillColor='00FF00';
        $moo->draw(true);
        
        

//global $happiDoc;
//include "charts/charts.php";
////$swf_file=$happiDoc."subpages/charts/charts.swf";
//echo InsertChart ( "charts/charts.swf", "charts/charts_library", "sample-charts.php", 400, 250 );

?>

