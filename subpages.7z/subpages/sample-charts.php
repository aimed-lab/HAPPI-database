<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
include "charts/charts.php";
$chart [ 'chart_type' ] = "bar";
$chart [ 'chart_data' ] = array ( array ( "",         "target", "disease" ),
                                  array ( "",     15,     10,     )
                                );
SendChartData ($chart);
?>
