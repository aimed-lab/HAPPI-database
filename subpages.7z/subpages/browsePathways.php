<script>
    $(document).ready(function(){
        $('#hpdPathTB').dataTable( {
            "bJQueryUI": true,
            "bDestroy":true,
            "bProcessing":true,
            "iDisplayLength": 25,
            "sPaginationType": "full_numbers"
        } );
    });
</script>
<style>
    #hpdPathTB{
        width: 500px;
        margin-bottom: 20px;
    }
    #hpdPathTB_wrapper{
        width: 500px;
        margin-left: 5%;
        margin-right: 5%;
    }
    #hpdPathTB td,th{
        text-align: left;
    }
    #hpdPathTB tr td.sorting_1{
        background-color: white;
    }
    
</style>
<?php
$happiDoc=include_once '../documents-location.php';
include_once $happiDoc.'classes/dbutility.php';
include_once $happiDoc.'classes/utility.php';
?>
<div id="titleDiv">
    <i>Note: Please click on the name of the pathway to view the list of proteins.</i><br/>
</div>
<div>
    <table id="hpdPathTB">
        <thead>
            <tr><th>Pathway Name</th></tr>
        </thead>
        <tbody>
            <?php
                $hpdPathways=dbutility::getHPDPathways();
                foreach($hpdPathways as $key){
                    $hpdId=$key[0];
                    $hpdName=$key[1];
            ?>
            <tr>
                <td>
                    <?php echo "<a href='pathwayProteins.php?path=$hpdId'>$hpdName</a>";?>
                </td>
            </tr>
            <?php
                }
            ?>
        </tbody>
    </table>
</div>

