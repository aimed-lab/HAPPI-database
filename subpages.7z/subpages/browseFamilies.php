<script>
    $(document).ready(function() {
        $('#pfamFamilyTB').dataTable({
            "bDestroy": true,
            "bProcessing": true,
            "iDisplayLength": 25,
            "sPaginationType": "full_numbers",
            //"sScrollY": "500px",
            "sScrollX": "800px",
            "bScrollCollapse": true,
            "aoColumns": [
                {"bSortable": null},
                {"bSortable": null},
                null
            ]
        });
    });
</script>
<style type="text/css">
    #pfamFamilyTB{
        width: 900px;
        margin-bottom: 20px;
    }
    #pfamFamilyTB_wrapper{
        width: 900px;
        padding-left: 5%;
        padding-right: 5%;
        margin-bottom: 5%;
    }
    #pfamFamilyTB td,th{
        text-align: left;
    }
    #pfamFamilyTB tr td.sorting_1{
        //background-color: white;
    }
    #pfamFamilyTB a{
        color:blue;
    }
</style>
<?php
$happiDoc = include_once '../documents-location.php';
include_once $happiDoc . 'classes/dbutility.php';
include_once $happiDoc . 'classes/utility.php';
?>
<div id="titleDiv">
    <p style="font-size: 14px;">
        <b>Note:</b> The protein family list is from Pfam database.<br/><br/>
        <i>Please click on family name to view the list of proteins.</i><br/></p>
</div>
<div>
    <table id="pfamFamilyTB" class='display' cellspacing="0" >
        <thead>
            <tr>
                <th>PFam Id</th>
                <th>Family Name</th>
                <th>No. of Proteins</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $pfamFamilies = dbutility::getPfamFamilyList();
            foreach ($pfamFamilies as $key) {
                $family_name = $key[0];
                $pfam_acc = $key[1];
                $proteinCnt = $key[2];
                ?>
                <tr>
                    <td>
                        <?php echo $pfam_acc; ?>
                    </td>
                    <td>
                        <?php echo $family_name; ?>
                    </td>
                    <td>
                        <?php echo "<a href='pfamilyProteins.php?pfamily=$pfam_acc;$family_name' target='_blank'>$proteinCnt</a>"; ?>
                    </td>
                </tr>
                <?php
            }
            ?>
        </tbody>
    </table>
</div>

