<script type="text/javascript">
    $(document).ready(function() {
        $('#statsTbl').dataTable({
            "bDestroy": true,
            "bProcessing": true,
            "iDisplayLength": 25,
            "sPaginationType": "full_numbers"
        });
    });
</script>
<style>

    #statsTbl a{
        color: blue;
    }
    #statsTbl th{
        text-align: center;
    }
</style>
<?php
if (isset($_GET['srcprotein'])) {
    $srcProtein = $_GET['srcprotein'];
}
if (!(isset($_SESSION))) {
    session_start();
}
$searchedList = explode(',', $srcProtein);

$happiDoc = include_once '../documents-location.php';
include_once $happiDoc . 'classes/dbutility.php';

$statsArry = dbutility::get_interaction_stats($searchedList);
?>
<table id="statsTbl" class='display' cellspacing="0" width="100%">
    <thead>
        <tr>
            <th>Protein_id</th>
            <th>Targeting Drug Count</th>
            <th>Associated Disease Count</th>
            <th>*&nbsp;HAPPI Interaction Count</th>
        </tr>
    </thead>
    <tbody>
<?php
foreach ($statsArry as $counts) {
    $protein = $counts[0];
    $drug_cnt = 0;
    $disease_cnt = 0;
    $interaction_cnt = '';
    $highInteraction_cnt = '';
    if (array_key_exists(1, $counts)) {
        $drug_cnt = $counts[1];
    } else {
        $drug_cnt = 0;
    }
    if (array_key_exists(2, $counts)) {
        $disease_cnt = $counts[2];
    } else {
        $disease_cnt = 0;
    }
    if (array_key_exists(3, $counts)) {
        $interaction_cnt = $counts[3];
    } else {
        $interaction_cnt = '';
    }
    if (array_key_exists(4, $counts)) {
        $highInteraction_cnt = $counts[4];
    } else {
        $highInteraction_cnt = '';
    }
    echo "<tr>"
    . "<td><a href='protein-description.php?protein=$protein' target=_blank>$protein</a></td>";
    if ($drug_cnt > 0) {
        echo "<td><a href='proteinDrugDetails.php?protein=$protein' target=_blank'>$drug_cnt</a></td>";
    } else {
        echo "<td>$drug_cnt</td>";
    }
    if ($disease_cnt > 0) {
        echo "<td><a href='proteinDiseaseDetails.php?protein=$protein' target=_blank'>$disease_cnt</a></td>";
    } else {
        echo "<td>$disease_cnt</td>";
    }
    echo "<td><a href='searchResults.php?srcprotein=$protein' target='_blank'>$highInteraction_cnt</a> ( $interaction_cnt )</td>"
    . "</tr>";
}
?>
    </tbody>
</table>