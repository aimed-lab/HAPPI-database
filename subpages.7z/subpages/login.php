<?php
 if(!isset($_SESSION)){
//if(!session_id()) {
        session_start();
    }

$happiDoc=include_once '../documents-location.php';
include_once $happiDoc.'classes/dbutility.php';
include_once $happiDoc.'classes/utility.php';

$userEmail = '';
$password = '';
//echo "In login";
if(isset($_POST['userEmail'])) {
    $userEmail = $_POST['userEmail'];
    $userEmail = utility::cleanData($userEmail);
    //echo $userEmail;
}

if(isset($_POST['password'])) {
    $passwordIn = $_POST['password'];
    $password = utility::cleanData($passwordIn);
    //echo $password;
}
if(($userEmail!='')&&($password !='')){
    if(!dbutility::emailExists($userEmail)){
        echo "<strong class='error' > The email is not registered. Please register to
               <a href='register.php' style =\" font-size:16px;text-decoration:underline\">Login</a>.</strong>";
    }else if(!dbutility::verifyUser($userEmail,$password)){
        echo "<strong class='error' >The email/password doesnot match our records.";
        echo "<br/>Please check your email/password.</strong>";
    }else{
        $_SESSION['logged']=true;
        $_SESSION['userEmail']=$userEmail;
        $details=dbutility::getUserDetails($userEmail, $password);
        $_SESSION['userId']=$details['USERID'];
        $_SESSION['fname']=$details['UFIRST_NAME'];
        $_SESSION['password']=$password;
        //header('Location:mypage.php') ;
        echo "logged";
    }
}
//echo "yes";
?>
