<?php

 echo "Interaction count goes here.";
 if(isset($_GET['srcprotein'])){
    $srcProtein=$_GET['srcprotein'];
    echo $srcProtein;
    //print_searchSummary($srcProtein);
}

//function print_searchSummary($list,$idtype) {
//        global $dbUtil;
//        $pro_list = array();
//
//        $outStr ='';
//        $outStr="<table id=\"recordTable\" align=\"center\" >";
//        if($idtype =='UniprotID') {
//            $outStr.="<th>Searched Protein</th>";
//            $outStr.="<th>Interaction Count</th>";
//            foreach($list as $uProt) {
//                $pro_list=$dbUtil->interactionCount($uProt);
//                foreach($pro_list as $prot=>$inter_count) {
//                    $outStr.="<tr><td>";
//                    $outStr.=$prot;
//                    $outStr.="</td><td>";
//                    $outStr.=$inter_count."</td";
//                    $outStr .= "</tr>";
//
//                }
//            }
//
//        }
//}
?>
<div>
    <table>
        <th>Searched Id</th>
        <th>Mapped protein</th>
        <th>Interaction Count</th>
        <tr>
            <td></td>
        </tr>
    </table>

</div>