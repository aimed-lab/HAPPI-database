<?php

 if(!(isset($_SESSION))) {
        session_start();
    }
//$userEmail=$_SESSION['userEmail'];
$happiDoc=include_once '../documents-location.php';
include_once $happiDoc.'classes/dbutility.php';
include_once $happiDoc.'classes/utility.php';

$oldpass='';
$newpass1='';
$newpass2='';


if((isset($_POST['newPass2']))&& (isset($_POST['newPass1'])) && (isset($_POST['oldPass']))) {
    //echo "All passwords set";
    $oldpass=$_POST['oldPass'];
    $newpass1=$_POST['newPass1'];
    $newpass2=$_POST['newPass2'];

    // clean input
    $oldpass = utility::cleanData($oldpass);
    $newpass1 = utility::cleanData($newpass1);
    $newpass2 = utility::cleanData($newpass2);
    if($newpass1 == $newpass2){
        resetPassword($oldpass,$newpass1);
    }else{
        echo "<strong class='error'>The two new password fields does not match</strong>";
    }

}else {
    echo "All passwords not set";
}

function resetPassword($oldpass,$newpass){
    
    //session_start();
    if(isset($_SESSION['logged'])){
        $userEmail = $_SESSION['userEmail'];
    }else{
        $userEmail='';
    }
    if(dbutility::verifyUser($userEmail, $oldpass)){
        dbUtility::resetPassword($userEmail,$newpass);
        print "<strong class='success'>Thank you. You have successfully updated your password.
            <br/>Please keep a record of your new password.</strong>";
    }else{
        print "<strong class='error'>The old password does not match.<br/>Please try again.</strong>";
    }
}

?>
