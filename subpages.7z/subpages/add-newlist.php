<?php
$happiDoc=include_once '../documents-location.php';
include_once $happiDoc.'classes/dbutility.php';
if(!isset($_SESSION)){
    session_start();
}
$uid=$_SESSION['userId'];

if((isset ($_POST['listName']))&& (isset ($_POST['description']))){
    $listname='';
    $listname =$_POST['listName'];
    $description =$_POST['description'];
    if(($listname!='')&&($description!='')){
        createNewList($listname,$description);
        echo "<span class='success'>List successfully created.</span>";
    }

}
function createNewList($listname,$description){
    global $uid;
    dbutility::createNewUserList($uid, $listname,$description);
}
?>
