<?php
//$happiDoc = include_once '../documents-location.php';
//include_once $happiDoc . 'classes/dbutility.php';
//include_once $happiDoc . 'classes/utility.php';
include_once  'classes/dbutility.php';
include_once   'classes/utility.php';
$a=1;
$searchItem = 'BRCA1_HUMAN';
$searchItem = chop($searchItem);
$searchedList = explode(',', $searchItem);
$interactions = dbutility::get_all_interactions($searchedList);
$interactionCnt = dbutility::get_interaction_cnt($searchedList);
$_SESSION['currentProtein'] = $searchItem;
print 'here';



?>