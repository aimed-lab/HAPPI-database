<?php
$happiDoc=include_once '../documents-location.php';
include_once $happiDoc.'classes/dbutility.php';
include_once $happiDoc.'classes/utility.php';
if(!isset($_SESSION)){
    session_start();
}
$logged='';
$uid='';
if(isset($_SESSION['logged']) && ($_SESSION['logged']==false)){
    $logged =false;
}else{
    if(isset($_SESSION['userId'])){
                $uid=$_SESSION['userId'];
    }else{
        $uid='';
    }
}
if($uid==''){
    echo "<strong class=error>Please <a href='signIn.php' style='color:blue; text-decoration:underline'>LOGIN</a> to rate the interactions.</strong>";
}else{

    if(isset ($_POST['rateId'])){

        $rateId =$_POST['rateId'];
        $baseId=$_POST['baseId'];
        if(($rateId != '')&&($baseId != '')){

            $interactors = utility::parseDataName($rateId,$baseId);
            $interactorsArry = explode(',', $interactors);

            if($baseId=='iExcel'){
                dbutility::addInteractionUserRating('Excellent', $uid, $interactorsArry);
                echo "<span class='success'>The interaction was successfully rated.</span><br/>";
            }
            if($baseId=='iGood'){
                dbutility::addInteractionUserRating('Good', $uid, $interactorsArry);
                echo "<span class='success'>The interaction was successfully rated.</span><br/>";
            }
            if($baseId=='iBad'){
                dbutility::addInteractionUserRating('Bad', $uid, $interactorsArry);
                echo "<span class='success'>The interaction was successfully rated.</span><br/>";
            }

        }
    }
}

?>
