<?php
$happiDoc=include_once '../documents-location.php';
include_once $happiDoc.'classes/dbutility.php';
include_once $happiDoc.'classes/utility.php';
if(!isset($_SESSION)){
    session_start();
}
$logged='';
if($_SESSION['logged']==false){
    $logged =false;
}else{
    if(isset($_SESSION['userId'])){
                $uid=$_SESSION['userId'];
    }else{
        $uid='';
    }
}

if(isset ($_POST['interactionList'])){
    $interactionList='';
    $listName='';
    $listDescription='';
    $interactionList =$_POST['interactionList'];

    if(isset ($_POST['listName'])){
        $listName=($_POST['listName']);
    }

    if(isset ($_POST['listDesc'])){
        $listDescription=($_POST['listDesc']);
    }


    if(($interactionList!='')&&($listName!='')){
        saveInteractionsList($listName,$listDescription,$interactionList);
        echo "<span class='success'>Interactions are successfully saved to the list.</span>";
    }

}
function saveInteractionsList($listname,$listDescription,$interactionList){
    global $uid;
    $interactionsArry=array();
    $baseInteractionsArry = explode('$', $interactionList);
    foreach($baseInteractionsArry as $value){
        $interaction = utility::parseDataName($value,'chk');
        if($interaction !=''){
            array_push($interactionsArry, $interaction);
        }
    }
    dbutility::saveInteractionsToList($uid, $listname,$listDescription,$interactionsArry);
}
?>
