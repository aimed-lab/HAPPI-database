<?php
 if(!isset($_SESSION)){
        session_start();
    }

$happiDoc=include_once '../documents-location.php';
include_once $happiDoc.'classes/dbutility.php';
include_once $happiDoc.'classes/utility.php';
include_once $happiDoc.'classes/mailUtility.php';

$userEmail = '';
$first_name = '';
$last_name = '';
$institution = '';

if(isset($_POST['uemail'])) {
    $userEmail = $_POST['uemail'];
    $userEmail = utility::cleanData($userEmail);
    //echo $userEmail;
}

if(isset($_POST['fName'])) {
    $first_name = $_POST['fName'];
    $first_name = utility::cleanData($first_name);
    //echo $userEmail;
}
if(isset($_POST['lName'])) {
    $last_name = $_POST['lName'];
    $last_name = utility::cleanData($last_name);
    //echo $userEmail;
}
if(isset($_POST['uInstitution'])) {
    $institution = $_POST['uInstitution'];
    $institution = utility::cleanData($institution);
    //echo $userEmail;
}
if(($userEmail!='')&&($first_name !='')&&($last_name !='')&&($institution !='')){
	
    if(dbutility::emailExists($userEmail)){
        echo "<strong class='error'> The entered email is already registered.<br/><br/>
                                    &nbsp;&nbsp;Please Login <a href='signIn.php' style ='text-decoration:underline'>here</a>.<br/><br/> &nbsp;OR <br/><br/>
                                    &nbsp;&nbsp;Request Password <a href='retrieve-credentials.php' style ='text-decoration:underline'>here</a>.</strong><br/><br/>";
    }else{
        $password=utility::createRandomPassword();
        dbutility::addUser($userEmail, $password, $first_name, $last_name, $institution);
        $status=sendMail($first_name, $userEmail, $password);
        if($status==1){
            print "<strong class='success'>You have been successfully registered. <br/>Please check your email for the login details.</strong><br/>";
        }else{
            print "<strong class='error'>An error occured while sending mail. Please use the contact form to the report error.</strong><br/>";
        }
    }
}else{
    echo "<strong class='error' >Please enter all the details.</strong>";
}



function sendMail($firstname,$email,$temp_pass){
	global $happiDoc;
    $subject="Welcome to HAPPI Portal";
    $body="<br/><br/>Hello $firstname,<br/>
        As per your request an account has been created at <a href='http://discovery.informatics.uab.edu/HAPPI/signIn.php'>HAPPI</a>.<br/>
        Please login using the following credentials.<br/>".
        "<br/> Login Id: $email <br/>
              Temporary Password : ".$temp_pass."<br/><i>It is recommended that you reset your password after login.</i>
              <br/><br/><br/>Best regards,
              <br/><br/>HAPPI Team";
    $attach='';
    $nameEmailArray= array("name" => $firstname,"email" => $email);

    $mailUtility = new MailUtility($nameEmailArray, $subject, $body,$attach);
    $status = $mailUtility->sendMail();
    return $status;

}

?>
