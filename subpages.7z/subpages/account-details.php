<script type="text/javascript">
            $(document).ready(function() {
                
                $('#personalDetailsForm').submit(function() {
                    //alert("submitted");
                    var errortxt = '';
                    var firstname = $('#firstname').val();
                    var lastname = $('#lastname').val();
                    var phone = $('#phone').val();
                    var institution = $('#insitution').val();
                    var scholar = $('#gscholar').val();
                    var linkedin = $('#linkedin').val();
                    var researchgate = $('#researchgate').val();
                    var userEmail = $('#userEmail').val();
                    if (userEmail !== '') {
                        $.post("subpages/update-profile.php", {firstname:firstname,lastname: lastname, phone: phone, institution: institution, userEmail:userEmail, scholar:scholar, linkedin:linkedin, researchgate:researchgate},
                            function(data) {
                                $('#updateDiv').html(data);
                            });
                        }
                    return false;
                });

                
            });
        </script>
<?php
if(!isset($_SESSION)){
        session_start();
}
$happiDoc=include_once '../documents-location.php';
$userEmail=$_SESSION['userEmail'];
$first_name = $_SESSION['fname'];
$userId=$_SESSION['userId'];
$pass=$_SESSION['password'];
include_once $happiDoc.'classes/dbutility.php';
$userDetails=dbutility::getUserDetails($userEmail, $pass);
$lastname='';
$org='';
$phone='';
$scholar='';
$linkedin='';
$researchgate='';

if(array_key_exists(2, $userDetails)) {
    $lastname = $userDetails[2];
} else {
    $lastname = '';
}
if(array_key_exists(3, $userDetails)) {
    $org = $userDetails[3];
} else {
    $org = '';
}
if(array_key_exists(4, $userDetails)) {
    $phone = $userDetails[4];
} else {
    $phone = '';
}
if(array_key_exists(5, $userDetails)) {
    $scholar = $userDetails[5];
} else {
    $scholar = '';
}
if(array_key_exists(6, $userDetails)) {
    $linkedin = $userDetails[6];
} else {
    $linkedin = '';
}
if(array_key_exists(7, $userDetails)) {
    $researchgate = $userDetails[7];
} else {
    $researchgate = '';
}
?>
<form id="personalDetailsForm" method="post" action="">
    <div id="updateDiv"></div>
    <fieldset style="margin-left:10%;margin-right:10%;margin-top:20px;margin-bottom:20px;">
        <div id="profileStatus"></div>
        <b>Profile</b><br/><br/>

        <label class="label txtRight">First Name: </label>
        <input id="firstname" name="firstname" type="text" class="textbox" value="<?php echo $first_name; ?>"/><br/>
        <label class="label txtRight">Last Name: </label>
        <input id="lastname" name="lastname" type="text" class="textbox"  value="<?php echo $lastname; ?>"/><br/>
        <label class="label txtRight">Phone No: </label>
        <input id="phone" name="phone" type="text" class="textbox" value="<?php echo $phone; ?>"/><br/>
        <label class="label txtRight">Institution: </label>
        <input id="insitution" name="insitution" type="text" class="textbox" value="<?php echo $org; ?>"/><br/>
        <label class="label txtRight">Google Scholar: </label>
        <input id="gscholar" name="gscholar" type="text" class="textbox" value="<?php echo $scholar; ?>"/><br/>
        <label class="label txtRight">LinkedIn Id: </label>
        <input id="linkedin" name="linkedin" type="text" class="textbox" value="<?php echo $linkedin; ?>"/><br/>
        <label class="label txtRight">ResearchGate Id : </label>
        <input id="researchgate" name="researchgate" type="text" class="textbox" value="<?php echo $researchgate; ?>"/><br/>
        <label class="label txtRight">Email (login email): </label>
        <input type="text" id="userEmail" class="textbox" disabled="disabled" value="<?php echo $userEmail; ?>"/><br/>
        <input id="saveProfile" type="submit" class="button" style="margin-left: inherit; margin-top: 10px;" value="Update Profile"/>
    </fieldset>
</form>