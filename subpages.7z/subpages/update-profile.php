<?php

 if(!isset($_SESSION)){
        session_start();
    }

$happiDoc=include_once '../documents-location.php';
include_once $happiDoc.'classes/dbutility.php';
include_once $happiDoc.'classes/utility.php';
include_once $happiDoc.'classes/mailUtility.php';

$userEmail = '';
$first_name = '';
$last_name = '';
$institution = '';
$scholar='';
$linkedin='';
$researchgate='';
$phone='';

if(isset($_POST['firstname'])) {
    $first_name = $_POST['firstname'];
    $first_name = utility::cleanData($first_name);
    //echo $userEmail;
}

if(isset($_POST['lastname'])) {
    $last_name = $_POST['lastname'];
    $last_name = utility::cleanData($last_name);
    //echo $userEmail;
}
if(isset($_POST['phone'])) {
    $phone = $_POST['phone'];
    $phone = utility::cleanData($phone);
    //echo $userEmail;
}
if(isset($_POST['institution'])) {
    $institution = $_POST['institution'];
    $institution = utility::cleanData($institution);
    //echo $userEmail;
}
if(isset($_POST['researchgate'])) {
    $researchgate = $_POST['researchgate'];
    $researchgate = utility::cleanData($researchgate);
    //echo $userEmail;
}
if(isset($_POST['scholar'])) {
    $scholar = $_POST['scholar'];
    $scholar = utility::cleanData($scholar);
    //echo $userEmail;
}
if(isset($_POST['linkedin'])) {
    $linkedin = $_POST['linkedin'];
    $linkedin = utility::cleanData($linkedin);
    //echo $userEmail;
}
if(isset($_POST['userEmail'])) {
    $userEmail = $_POST['userEmail'];
    //$userEmail = utility::cleanData($userEmail);
    //echo $userEmail;
}
if($userEmail != ''){
    dbutility::updateUserDetails($userEmail,$first_name,$last_name,$institution,$phone,$scholar,$linkedin,$researchgate);
    echo "<b> The profile is successfully saved. </b>";
}
?>