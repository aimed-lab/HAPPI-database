<?php
if(isset($_GET['srcprotein'])){
    $srcProtein=$_GET['srcprotein'];
    //echo $srcProtein;
    //print_searchSummary($srcProtein);
}
if(!(isset($_SESSION))) {
        session_start();
    }

//if(isset($_SESSION['searchInteractionList'])){
    //$srcInteractionArry = $_SESSION['searchInteractionList'];
    $searchedList=explode(',',$srcProtein);
    $happiDoc=include_once '../documents-location.php';
    include_once $happiDoc.'classes/dbutility.php';
    //include ('../classes/dbUtility.php');
    //$targetList = dbutility::get_all_DrugTargets($searchedList);
    $targetList = dbutility::get_TargetDrug_Cnt($searchedList);
    
    $diseaseList = dbutility::get_DiseaseProtein_cnt($searchedList);
   
    $GoType = dbutility::getGoTypeCnt($searchedList);

//}

?>
<script>
    $('legend.target').click(function(){
            $(this).siblings().slideToggle("slow");
     });
     $('legend.disease').click(function(){
            $(this).siblings().slideToggle("slow");
     });
     $('legend.ontology').click(function(){
            $(this).siblings().slideToggle("slow");
     });
     $('legend.ontologyCel').click(function(){
            $(this).siblings().slideToggle("slow");
     });
     $('legend.ontologyMol').click(function(){
            $(this).siblings().slideToggle("slow");
     });
     $('#dTargetTB').dataTable( {
            //"bJQueryUI": true,
            "bDestroy":true,
            "bProcessing":true,
            "sPaginationType": "full_numbers"
        } );
    $('#sDiseaseTB').dataTable( {
        //"bJQueryUI": true,
        "bDestroy":true,
        "bProcessing":true,
        "sPaginationType": "full_numbers"
    } );
    $('#sCellularTB').dataTable( {
        //"bJQueryUI": true,
        "bDestroy":true,
        "bProcessing":true,
        "sPaginationType": "full_numbers"
    } );
    $('#sMolTB').dataTable( {
        //"bJQueryUI": true,
        "bDestroy":true,
        "bProcessing":true,
        "sPaginationType": "full_numbers"
    } );
</script>
<style>
    #dTargetTB{
        width: 600px;
        margin-bottom: 20px;
    }
    #dTargetTB_wrapper{
        width: 600px;
        margin-left: 5%;
        margin-right: 5%;
    }
    #dTargetTB_filter{
        text-align: left;
    }
    #dTargetTB td,th{
        text-align: left;
    }
    #dTargetTB tr td.sorting_1{
        background-color: white;
    }

    #sDiseaseTB{
        width: 600px;
        margin-bottom: 20px;
    }
    #sDiseaseTB_wrapper{
        width: 600px;
        margin-left: 5%;
        margin-right: 5%;
    }
    #sDiseaseTB_filter{
        text-align: left;
    }
    #sDiseaseTB td,th{
        text-align: left;
    }
    #sDiseaseTB tr td.sorting_1{
        background-color: white;
    }
    
    #sCellularTB{
        width: 600px;
        margin-bottom: 20px;
    }
    #sCellularTB_wrapper{
        width: 600px;
        margin-left: 5%;
        margin-right: 5%;
    }
    #sCellularTB_filter{
        text-align: left;
    }
    #sCellularTB td,th{
        text-align: left;
    }
    #sCellularTB tr td.sorting_1{
        background-color: white;
    }
    
    #sMolTB{
        width: 400px;
        margin-bottom: 20px;
    }
    #sMolTB_wrapper{
        width: 500px;
        margin-left: 5%;
        margin-right: 5%;
    }
    #sMolTB_filter{
        text-align: left;
    }
    #sMolTB td,th{
        text-align: left;
    }
    #sMolTB tr td.sorting_1{
        background-color: white;
    }

</style>
<div>
    <i>Click to expand for the list</i>
    <fieldset>
        <legend class="target" style="font-size:14px; font-weight: bold;" >Drug Targets</legend>
        <div style="display:none;">
        <br/>
        <b><i>Click on the protein name and drug counts for details.</i></b>
        <br/>
        <br/><br/>
         <?php
            //echo "Drug Count: ".$cntTarget."</br>";
//            foreach($targetList as $value){
//                echo "<a href='protein-description.php?protein=$value' target=_blank>$value</a><br/>";
//            }
        ?>
        <table id="dTargetTB" class="display compact">
            <thead>
                <tr>
                    <th>Uniprot Id</th>
                    <th>Drug Count</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    foreach($targetList as $value){
                        $protein_id = $value[0];
                        $drug_cnt = $value[1];
                        echo "<tr>"
                        . "<td><a href='protein-description.php?protein=$protein_id' target=_blank>$protein_id</a></td>"
                        . "<td><a href='proteinDrugDetails.php?protein=$protein_id' target=_blank'>$drug_cnt</a></td>"
                        . "</tr>";
                    }
                 ?>               
                
            </tbody>
        </table>
        </div>
    </fieldset>

    <fieldset>
        <legend class="disease" style="font-size:14px; font-weight: bold;">Diseases</legend>
        <div style="display:none;">
            <br/>
        <i>Click on the disease names for list of proteins.</i>
        <br/>
        <br/>
             <table id="sDiseaseTB" class="display compact">
                <thead>
                    <tr>
                        <th>Disease Name</th>
                        <th>Protein Count</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        foreach($diseaseList as $value){
                            $disease =$value[0];
                            $procnt =$value[1];
                            echo "<tr>"
                                . "<td><a href='diseaseProteins.php?dis=$disease' target=_blank>$disease</a></td>"
                                . "<td><a href='diseaseProteins.php?dis=$disease' target=_blank>$procnt</a></td>"
                            . "</tr>";
                        }

                     ?>
                </tbody>
            </table>
       
        </div>
    </fieldset>
    
    <fieldset>
        <legend class="ontology" style="font-size:14px; font-weight: bold;">Gene Ontology</legend>
        <div style="display:none;">
            <br/>
            <i>Click on the Ontology to view details.</i>
            <br/>
            <br/>
                 <table id="sCellularTB" class="display compact">
                    <thead>
                        <tr><th>Go Description</th>
                        <th>GO Type</th>
                        <th>Protein Counts</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $desc='';
                        $type='';
                        $protein_cnt='';
                            foreach($GoType as $value){
                                $desc=$value[0];
                                $type=$value[1];
                                $protein_cnt=$value[2];
                                echo "<tr>"
                                . "<td>$desc</td>"
                                . "<td>$type</td>"
                                . "<td>$protein_cnt</td>"
                                . "</tr>";
                            }

                         ?>
                    </tbody>
                </table>

            </div>
        </fieldset>
            <!--
        <fieldset>
            <legend class="ontologyMol" style="font-size:14px; font-weight: bold;">Molecular</legend>
            <div style="display:none;">
            <br/>
            <i>Click on the Ontology to view details.</i>
            <br/>
            <br/>
                 <table id="sMolTB" class="display compact">
                    <thead>
                        <tr><th>Molecular</th></tr>
                    </thead>
                    <tbody>
                        <?php
                            foreach($molecularTypes as $value){
                                echo "<tr><td>$value</td></tr>";
                            }

                         ?>
                    </tbody>
                </table>

            </div>
        </fieldset>-->