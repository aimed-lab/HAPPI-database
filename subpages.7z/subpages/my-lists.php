<?php
if(!isset($_SESSION)){
        session_start();
}
$happiDoc=include_once '../documents-location.php';
include_once $happiDoc.'classes/dbutility.php';
include_once $happiDoc.'classes/utility.php';
$userEmail=$_SESSION['userEmail'];
$first_name = $_SESSION['fname'];
$userId=$_SESSION['userId'];
?>
<script>
    $(document).ready(function(){
        //$( "#newList-dialog-form" ).dialog( "destroy" );
       //$( "#deleteList-dialog-form" ).dialog( "destroy" );


            $( "#newList-dialog-form" ).dialog({
                autoOpen: false,
                modal: true,
                buttons: {
                    "Create": function() {
                             var listName = $('#listname').val();
                             var description = $('#listDesc').val();
                             if((listName=='')||(description=='')){
                                 $('#dialogStatus').html('<span class="error">List name and the description is required.</span><br/>');
                             }else{
                                 $.post("subpages/add-newlist.php",{listName:listName,description:description },
                                    function(data) {
    //                                    $("#addTagStatus").html(data);
    //                                    $("#currentTags").append("<option>"+tagName+"</option>");
    //                                    $('#addTagStatus').val('');
                                        $('#status').html(data);
                                        $( this ).dialog( "close" );
                                    });
                                    $( this ).dialog( "close" );
                             }
                             
                        //$( this ).dialog( "close" );
                    },
                    Cancel: function() {
                        $( this ).dialog( "close" );
                    }
                }
            });


//            function closeDialog()
//            {
//                $('#newList-dialog-form').dialog("close");
//            }
            $('#newList').click(function() {
                $( "#newList-dialog-form" ).dialog( "open" );
        });


        // delete list dialog
        $( "#deleteList-dialog-form" ).dialog({
                autoOpen: false,
                modal: true,
                buttons: {
                    "Delete": function() {
//                        window.location.href = 'phps/download.php?download_file=jquery-ui-1.8.9.custom.zip';
//                        setTimeout(closeDialog, 1500);
                        var deleteList='';
                        //var dataSet = $('#hcurrentDataSet').val();
                         $("#currentLists option:selected").each(function(){
                                //alert($(this).val());
                                deleteList+=$(this).val()+";";
                                //alert(deleteList);
                            });
                            if(deleteList===''){
                                $('#deleteStatus').html("<span class='error'>Please select the list to be deleted.</span>")
                            }else{
                                  $.post("subpages/delete-user-list.php", {deleteList:deleteList},
                                    function(data) {
                                        $("#status").html(data);
                                        $( this ).dialog( "close" );
                                        //working.busy("hide");
//                                        $("#currentTags option:selected").each(function(){
//                                            $("#currentTags option[value='"+$(this).val()+"']").remove();
//                                        });

                                 });
                            }
                    },
                    Cancel: function() {
                        $( this ).dialog( "close" );
                    }
                }
            });

            $('#deleteList').click(function() {
                $( "#deleteList-dialog-form" ).dialog( "open" );
        });

        $('#sortListTable').dataTable( {
                //"bJQueryUI": true,
                "sPaginationType": "full_numbers"                
        } );

    });
</script>
<style>
            .dataTables_wrapper {
                width:800px;

            }
            #sortListTable_wrapper .fg-toolbar
            {
                font-size: 0.8em;
            }
            #sortListTable_wrapper_length
            {
                width:20%;
            }
        </style>
<div id="actionDiv" style="margin-top:5px;margin-bottom: 25px;">
    <span style="margin:5px;"><a href="#" id="newList"><img src="images/add1.png" style="width:15px;height:15px;margin-right: 2px;" />New</a></span>
    <span style="margin:5px;"><a href="#" id="deleteList"><img src="images/delete2.jpg" style="width:14px;height:14px;margin-right: 2px;"/>Delete</a></span>
    <!--<span style="margin:5px;"><a href="#"><img src="images/merge-arrows.png" style="width:15px;height:15px;margin-right: 2px;"/>Merge</a></span>-->
</div>
<div id="status"></div>
<?php
if($userId!=''){

    echo "<div id='data'>";
            $userLists=dbutility::getUserList($userId);
            
            $cntULists = count($userLists);
            //echo "cnt:".$cntULists;
    echo "</div>";
    
    if($cntULists < 1){
    ?>
        <p>
            You have yet not created any list to save interactions.<br/>
            You can search interactions and then save them into your lists.
        </p>
   <?php
    }else{
        echo "You currently have $cntULists saved interaction lists.<br/><br/>"
        ?>
        <div style="padding-top:30px;">
        <table id="sortListTable" class="display" cellspacing="0">
            <thead>
                <tr>
                    <th>List Name</th>
                    <th>No. of Interactions</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
            <?php
                foreach($userLists as $list){
                    //$checkId="chk".$partners[0].",$partners[1]"
                    $name=$list[0];
                    $interCNT=$list[1];
                    
                    ?>
            
                <tr>
                    <td><?php echo $name; ?></td>
                    <td><?php echo  $interCNT;?></td>
                    <td><?php 
                    if($interCNT > 0){
                        echo  "<a href='list-view.php?lname=$name' target='_blank' style='color:blue; text-decoration:underline;'>View</a>";
                    } else {
                        echo "";
                    }
                    ?>
                    </td>
                </tr>
                
            <?php
            }

        ?>
            </tbody>
        </table>
        </div>
<?php
    }
}
?>
<div id="newList-dialog-form" title="Create New List">
    <div id="dialogStatus"></div>
    <form>
        <label class="label" >Name</label><br/>
        <input type="text" id="listname" class="textbox"/><br/>
        <label class="label">Description</label><br/>
        <textarea id="listDesc" rows="3" cols="24"></textarea><br/>
    </form>
</div><!-- End New list dialog-form -->

<div id="deleteList-dialog-form" title="Delete List">
    <div id="deleteStatus"></div>
    <form>
        <i style="font-size:10px;">Multiple list could be selected.<br/><b> The action could not be undone.</b></i>
        <br/><br/>
        <label class="label">Select Lists</label><br/>
        <select id='currentLists' multiple style='width:200px;'>
            <?php
                foreach($userLists as $list){
                    echo "<option value='$list[0]'>$list[0]";
                }
            ?>
        </select>

    </form>
</div><!-- End New list dialog-form -->