<?php
if (!isset($_SESSION)) {
    session_start();
}
?>
<style>
    #searchedInteractionTb{
        margin-bottom: 20px;
        margin-left: 20px;
    }
    #searchedInteractionTb_wrapper{
    }
    #searchedInteractionTb td,th{
        text-align: left;
    }
    #searchedInteractionTb_filter{
        text-align: left;
        width: 250px;
    }
    #searchedInteractionTb a{
        color: blue;
    }
</style>
<script>
    $(document).ready(function() {
        $('input[id^="saveInter"]').click(function() {
            var logged = ($(this).attr('id')).substring(9);
            if (logged === 'True') {
                saveInteractionDialog();
            } else if (logged === 'False') {
                $('#status').html("<span class='error'>Please <a href='signIn.php' style='color:blue;'>Login</a> to save interactions.</span>");
                loginDialog();
            }

        });

        //$( "#login-dialog-form" ).dialog( "destroy" );

        function loginDialog() {
            $("#login-dialog-form").dialog("open");
        }

        $("#login-dialog-form").dialog({
            autoOpen: false,
            modal: true,
            width: 450,
            buttons: {
                "Sign In": function() {
                    document.location = 'signIn.php';
                    $(this).dialog("close");

                },
                "Register": function() {
                    document.location = 'register.php';
                    $(this).dialog("close");
                },
                Cancel: function() {
                    $(this).dialog("close");
                }
            }
        });

        //$( "#list-name-dialog-form" ).dialog( "destroy" );

        function saveInteractionDialog() {
            var cnt = $('input[id^="chk"]:checked').length;
            if (cnt > 0) {
                $("#list-name-dialog-form").dialog("open");
                $('#logstatusDiv').html("");
            } else {
                alert("No interactions selected for saving to list.");
                $('#logstatusDiv').html("<span class='error'>Please select the interaction to save.</span>");
            }
        }

        $("#list-name-dialog-form").dialog({
            autoOpen: false,
            modal: true,
            buttons: {
                "Submit": function() {
                    var checkedAry = '';
                    $('input[id^="chk"]:checked').each(function() {
                        checkedAry = checkedAry + $(this).attr('id') + "$";
                    });
                    if (checkedAry !== '') {
                        var newList = $('#newList').val();
                        var selectList = $('#selectList').val();
                        var listDesc = $('#newListDesc').val();
                        if ((newList === '') && (selectList === '')) {
                            $('#listStausDiv').html("<br/><strong class='error'>Please provide a list name to save the interactions to</strong>.");
                        } else if ((newList !== '') && (selectList !== '')) {
                            $('#listStausDiv').html("<br/>strong class='error'>Please provide only one list name at a time to save the interactions.</strong>");
                        } else {
                            var listName = '';
                            if (newList !== '') {
                                listName = newList;
                            } else if (selectList !== '') {
                                listName = selectList;
                            }
                            var working = jQuery(this).busy({img: 'images/busy.gif'});
                            $.post("subpages/save-interactions.php", {listName: listName, listDesc: listDesc, interactionList: checkedAry},
                            function(data) {
                                working.busy("hide");
                                $('#statusDiv').html(data);
                                $(this).dialog("close");
                            });
                        }
                        //$( this ).dialog( "close" );
                    } else {
                        $('#statusDiv').html("<span class='error'>Please check the interactions to save.</span>");
                    }
                },
                Cancel: function() {
                    $(this).dialog("close");
                }
            }
        });
        $('a[id^="iExcel"]').click(function() {
            var rateId = $(this).attr('id');
            var baseId = "iExcel";
            var working = jQuery(this).busy({img: 'images/busy.gif'});
            $.post("subpages/rate-interactions.php", {rateId: rateId, baseId: baseId},
            function(data) {
                working.busy("hide");
                $('#status').html(data);
            });

        });
        $('a[id^="iBad"]').click(function() {
            var rateId = $(this).attr('id');
            var baseId = "iBad";
            var working = jQuery(this).busy({img: 'images/busy.gif'});
            $.post("subpages/rate-interactions.php", {rateId: rateId, baseId: baseId},
            function(data) {
                working.busy("hide");
                $('#status').html(data);
            });
        });
        $('#searchedInteractionTb').dataTable({
            "bDestroy": true,
            "bProcessing": true,
            "iDisplayLength": 25,
            "sPaginationType": "full_numbers",
            "aoColumns": [
                null,
                null,
                null,
                null,
                null,
                null,
                {"bSortable": null},
                {"bSortable": null}
            ]

        });
    });
</script>
<?php
$happiDoc = include_once '../documents-location.php';
include_once $happiDoc . 'classes/dbutility.php';
include_once $happiDoc . 'classes/utility.php';

if (isset($_GET['srcprotein'])) {
    $searchItem = $_GET['srcprotein'];
} else {
    //$searchItem = $_POST['searchProtein'];
}
$searchItem = chop($searchItem);
$searchedList = explode(',', $searchItem);
$interactions = dbutility::get_all_interactions($searchedList);
$interactionCnt = dbutility::get_interaction_cnt($searchedList);
$_SESSION['currentProtein'] = $searchItem;

if (isset($_SESSION['logged']) && ($_SESSION['logged'] == true)) {
    $logged = true;
} else {
    $logged = false;
}
$interactionStr = "";
$interactionFile = $happiDoc . "downloadFiles/all-searched-happi-interactions.txt";
$psiFile = $happiDoc . "downloadFiles/all-searched-happi-psi.xml";
//$txtoutfile="all-searched-happi-interactions.txt";
//$fp=fopen($interactionFile,"w");
//$chkAllId= 'chkAll'.$searchItem;
$tableId = "searchedInteractionTb" . $searchItem;
?>

<p style="line-height:2">The table lists <b style="text-decoration:underline;"><?php echo count($interactions); ?></b> (medium- to high-quality) out of <b style="text-decoration:underline;"><?php echo $interactionCnt[0]; ?></b> (all quality) protein-protein interactions 
    found in HAPPI. <br/>
    To retrieve low-quality data, go to the "Advanced Retrieval: section <a href="advSearch.php" style="color:blue">here</a>.
</p>


<table id="searchedInteractionTb" class="display" cellspacing="0" width="100%">
    <thead>
        <tr style="text-align:left;">
            <th>Protein A</th>
            <th>Protein B</th>
            <th >Data Source</th>
            <th style="width:35px;">Known Type</th>
            <th style="width:35px;">Effect</th>
            <th style="width:42px;">Quality Rating</th>
            <th style="width:180px;">User Curation</th>
            <th style="width:5px;">Save</th>
        </tr>
    </thead>
    <tbody>
        <?php
        foreach ($interactions as $partners) {
            $checkId = "chk" . $partners[0] . ",$partners[1]";
            $iExcel = "iExcel" . $partners[0] . ",$partners[1]";
            $iBad = "iBad" . $partners[0] . ",$partners[1]";
            $datasrc = '';
            $mode = '';
            $action = '';
            $excelCnt = 0;
            $badCnt = 0;
            $annotateCnt = 0;
            $commentsCnt = 0;
            $proteinA = $partners[0];
            $proteinB = $partners[1];
            if (array_key_exists(3, $partners)) {
                $datasrc = $partners[3];
                $datasrc = str_replace('|', ', ', $datasrc);
                $datasrc = str_replace('hap1', 'HAPPI1', $datasrc);
                $datasrc = str_replace('HAPPI1_eSTR', 'HAPPI1', $datasrc);
                $datasrc = str_replace('HAPPI1_pSTR', 'HAPPI1', $datasrc);
                $datasrc = str_replace('HAPPI1_BIND', 'HAPPI1', $datasrc);
            } else {
                $datasrc = 'null';
            }
			$datasrcPiece = explode(", ", $datasrc);
			$datasrcPiece = array_unique($datasrcPiece);
			$datasrc = implode(",", $datasrcPiece );
            $star = trim($partners[4]);
            //$proteinB=$partners[1];
            if (array_key_exists(5, $partners)) {
                $excelCnt = $partners[5];
            } else {
                $excelCnt = 0;
            }
            if (array_key_exists(6, $partners)) {
                $badCnt = $partners[6];
            } else {
                $badCnt = 0;
            }
            if (array_key_exists(7, $partners)) {
                $mode = $partners[7];
            } else {
                $mode = 'association';
            }
            if (array_key_exists(8, $partners)) {
                $action = $partners[8];
            } else {
                $action = 'unknown';
            }
            if (array_key_exists(9, $partners)) {
                $commentsCnt = $partners[9];
            } else {
                $commentsCnt = 0;
            }
            $interactionStr = $interactionStr . $proteinA . "\t" . $proteinB . "\t" . $star . PHP_EOL;
            //fwrite($fp,"$proteinA\t$proteinB\n");
            ?>
            <tr>
                <td><a href="protein-description.php?protein=<?php echo $proteinA; ?>" style="align:left;"><?php echo $proteinA; ?></a></td>
                <td><a href="protein-description.php?protein=<?php echo $proteinB; ?>" style="align:left;"><?php echo $proteinB; ?></a></td>
                <td style="word-break:break-all;"><?php echo $datasrc; ?>
                <td style="word-break:break-all;"><?php echo $mode; ?>
                <td style="word-break:break-all;"><?php echo $action; ?>
                <td><?php
                    if ($star == '5_STAR') {
                        echo "<img src='images/stars5-5.png' alt='5-star' width='42px'/>";
                    } else if ($star == '4_STAR') {
                        echo "<img src='images/stars4-5.png' alt='4-star' width='42px' />";
                    } else if ($star == '3_STAR') {
                        echo "<img src='images/stars3-5.png' alt='3-star' width='42px'/>";
                    }
                    ?>
                </td>
                <td>
                    <span style="position:relative;font-size:10px;color: green; font-weight:bold; width:20px;height:20px;floating:left;"> 
                        <a href="#" id="<?php echo $iExcel; ?>" title="Rate as valid"> 
                            <img alt="valid PPI" src="images/thumbs-up-2.jpg" width="18" height="18" style="z-index:-1"/>
                        </a>
                        <?php echo $excelCnt; ?>&nbsp;&nbsp;
                    </span>

                    <span style="position:relative;font-size:10px;color: red; font-weight:bold; width:20px;height:20px;floating:left;"> 
                        <a href="#" id="<?php echo $iBad; ?>" title="Rate as invalid"> 
                            <img alt='invalid PPI' src="images/thumbs-down-2.jpg" width="18" height="18" style="z-index:-1"/>
                        </a>              
                        <?php echo $badCnt; ?>&nbsp;&nbsp;
                    </span>

                    <span style="position:relative;font-size:10px;color: blue;font-size: 10px;height:20px;floating:left">
                        <a href="annotate.php?PA=<?php echo $proteinA; ?>&PB=<?php echo $proteinB; ?>" target="_blank" title="Add PPI details">
                            <img alt='comments' src="images/annotate.png" width="18" height="18" />
                        </a>
                        <?php echo $commentsCnt; ?>&nbsp;&nbsp;
                    </span>

                </td>
                <td><?php echo "<input type='checkbox' id=$checkId style='align:left'/>" ?> </td>
            </tr>
            <?php
        }
        utility::writeInteractionFile($interactionFile, $interactionStr, $psiFile);
        //fclose($fp);
        ?>

    </tbody>
</table>

<div id="status"></div>
<p>
    <span>
        <?php
        if ($logged) {
            echo "<input type='image' id='saveInterTrue' src='images/savetoaccount.png' style='float:left' width='50' height='50' alt='Save to Account' title='Save to Account'/>";
        } else {
            echo "<input type='image' id='saveInterFalse' src='images/savetoaccount.png' style='float:left' width='50' height='50' alt='Save to Account' title='Save to Account'/>";
        }
        ?>
    </span>
    &nbsp;&nbsp;
    <span> <a href="subpages/download.php?download_file=all-searched-happi-interactions.txt"><img src="images/download.png" alt="Download PPI" height="50" width="50" style="float:left" title="Download PPI Table"></a></span>
</p>

<!-- Dialog Boxes -->
<div id="login-dialog-form" title="Login">
    You are not logged in!!
    <br/>
    Please login or register to save the interactions!!
</div><!-- End login-dialog-form dialog-form -->

<div id="list-name-dialog-form" title="Choose List">
    <?php
    if (isset($_SESSION['userId'])) {
        $uid = $_SESSION['userId'];
    } else {
        $uid = '';
    }
    ?>
    <i>Create a new list OR select from existing list to save interactions.</i>
    <div id="listStausDiv"></div>
    <form>
        <fieldset>
            <legend>New List</legend>
            <label class="label">List Name:</label>
            <input id="newList" name="newList" type="text"/>
            <label>List description</label>
            <textarea id="newListDesc" rows="5" cols="20"></textarea>
        </fieldset>
        <br/><center><b>OR</b></center>
        <fieldset>

            <legend>Select List</legend>
            <label class="label">List Name:</label>
            <select id="selectList">
                <option value='' selected="selected"></option>
                <?php
                $userLists = dbutility::getUserList($uid);
                foreach ($userLists as $list) {
                    echo "<option value='$list[0]'>$list[0]</option>";
                }
                ?>
            </select>
        </fieldset>


    </form>
</div><!-- End New list dialog-form -->



