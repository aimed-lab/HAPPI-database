<script>
    $(document).ready(function(){

        $("#myAccountPasswordResetForm").validate({
     rules: {
                currentPass: {
                    required: true
                },
                newPass1: {
                    required: true
                },
                newPass2:{
                    required: true
                }
            },
            //set messages to appear inline
            messages: {

            },
            submitHandler: function(form){
                var oldPass = $('#currentPass').val();
                    var newPass1 = $('#newPass1').val();
                    var newPass2 = $('#newPass2').val();
                    $.post("subpages/resetOldPass.php", { oldPass:oldPass,newPass1:newPass1,newPass2:newPass2 },
                    function(data) {
                        $("#status").html(data);
                        $('#currentPass').val('');
                        $('#newPass1').val('');
                        $('#newPass2').val('');
                    });
                        return false;
            }

    });
        $('#resetPass').click(function(){
            $('#myAccountPasswordResetForm').triggerHandler('submit');

        });
    });
</script>
<form id="myAccountPasswordResetForm">
        <fieldset style="margin-left:10%;margin-right:10%;margin-top:20px;margin-bottom:20px;">
                <div id="status"></div>
                <br/>
                <label class="label">Current Password: </label><br/>
                <input id="currentPass" name="currentPass" type="password" class="textbox required" /><br/>
                <label class="label">New Password: </label><br/>
                <input id="newPass1" name="newPass1" type="password" class="textbox required" /><br/>
                <label class="label" style="width:200px;">Re-enter New Password: </label><br/><br/>
                <input id="newPass2" name="newPass2" type="password" class="textbox required" /><br/><br/>
                <input id="resetPass" type="button" class="button" value="Reset Password"/>

        </fieldset>

    </form>
